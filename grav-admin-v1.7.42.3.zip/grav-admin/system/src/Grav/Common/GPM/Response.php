<?php
// Create alias for the deprecated class.
class_alias(\Grav\Common\HTTP\Response::class, \Grav\Common\GPM\Response::class);
